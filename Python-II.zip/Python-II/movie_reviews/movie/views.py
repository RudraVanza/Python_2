from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def home(request):
    searchTerm = request.GET.get("searchMovie")
    return render(request,"home.html",{"name":"Rudra" , "moviename" : searchTerm})
def about(request):
    return HttpResponse('<h1>Wellcome To About Page</h1>')
def signUp(request):
    email = request.GET.get("email")
    return render(request , "SignUp.html" , {"email":email})
