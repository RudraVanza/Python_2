from django.shortcuts import render

# Create your views here.
def details(request):
    return render(request , "MyData.html",{"name":"Rudra","eno":"23002171310176","div":"D7"}) 